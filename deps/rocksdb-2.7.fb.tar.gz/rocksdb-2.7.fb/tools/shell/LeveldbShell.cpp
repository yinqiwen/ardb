

#include "ShellContext.h"

int main(int argc, char ** argv) {
  ShellContext c(argc, argv);
  c.run();
}
